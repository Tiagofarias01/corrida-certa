package com.corridacerta

/**
 * Extrai valor (R$), km e minutos do texto da tela de oferta.
 * Formatos comuns:
 *   Uber:  "R$ 24,50"  "4 min (1,2 km) de distância"  "Viagem de 18 min (11,3 km)"
 *   99:    "R$ 24,50"  "1,2 km · 4 min" ...
 */
object OfferParser {
    data class Offer(val price: Double, val km: Double, val min: Double)

    private val priceRe =
        Regex("""R\$\s*(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)(?![\d.,]*\s*/)""")
    private val minKmRe = Regex(
        """(\d{1,3})\s*min(?:utos?)?\W{0,8}?(\d{1,3}(?:[.,]\d{1,2})?)\s*km""",
        RegexOption.IGNORE_CASE
    )
    private val kmMinRe = Regex(
        """(\d{1,3}(?:[.,]\d{1,2})?)\s*km\W{0,8}?(\d{1,3})\s*min""",
        RegexOption.IGNORE_CASE
    )
    // "1 h 5 min (40 km)" -> trata horas
    private val hMinKmRe = Regex(
        """(\d{1,2})\s*h(?:\s*(\d{1,2})\s*min)?\W{0,8}?(\d{1,3}(?:[.,]\d{1,2})?)\s*km""",
        RegexOption.IGNORE_CASE
    )

    private fun toD(s: String): Double {
        val t = if (s.contains(',')) s.replace(".", "").replace(',', '.') else s
        return t.toDoubleOrNull() ?: 0.0
    }

    // valores que NÃO são o preço da corrida (tela inicial da Uber: passes, dinâmica, metas)
    private val ignoreBefore = listOf("+", "ganhos de", "preço", "preco", "passe", "meta", "até", "ate")

    private fun isNoise(t: String, start: Int): Boolean {
        val before = t.substring(maxOf(0, start - 14), start).lowercase().trimEnd()
        return ignoreBefore.any { before.endsWith(it) }
    }

    fun parse(raw: String): Offer? {
        val t = raw.replace('\u00A0', ' ').replace('\u202F', ' ')

        // pares (posição, minutos, km)
        val hours = hMinKmRe.findAll(t).map {
            val h = it.groupValues[1].toDouble()
            val m = it.groupValues[2].toDoubleOrNull() ?: 0.0
            Triple(it.range, h * 60 + m, toD(it.groupValues[3]))
        }.toList()
        fun insideHours(r: IntRange) = hours.any { h -> r.first in h.first }

        // "4 min (1,2 km)" (Uber) ou "1,2 km • 4 min" (99): usa o formato que achar mais pares
        val a = minKmRe.findAll(t).filter { !insideHours(it.range) }
            .map { Triple(it.range, it.groupValues[1].toDouble(), toD(it.groupValues[2])) }
            .toList()
        val b = kmMinRe.findAll(t).filter { !insideHours(it.range) }
            .map { Triple(it.range, toD(it.groupValues[2]), toD(it.groupValues[1])) }
            .toList()
        val found = (if (b.size > a.size) b else a) + hours
        val sorted = found.sortedBy { it.first.first }
        if (sorted.isEmpty()) return null
        val firstPos = sorted.first().first.first

        // preço: o R$ mais perto ANTES do 1º "min/km" (ou o 1º depois), ignorando passes/dinâmica
        val prices = priceRe.findAll(t)
            .filter { !isNoise(t, it.range.first) }
            .map { it.range.first to toD(it.groupValues[1]) }
            .filter { it.second in 3.0..3000.0 }
            .toList()
        val price = prices.lastOrNull { it.first < firstPos }?.second
            ?: prices.firstOrNull { it.first > firstPos }?.second
            ?: return null

        // 1º par = até o passageiro, 2º = viagem
        val used = sorted.take(2)
        val min = used.sumOf { it.second }
        val km = used.sumOf { it.third }
        if (km <= 0.0 || min <= 0.0) return null

        return Offer(price, km, min)
    }
}
