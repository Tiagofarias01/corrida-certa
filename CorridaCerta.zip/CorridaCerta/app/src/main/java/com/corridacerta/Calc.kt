package com.corridacerta

import java.util.Locale

object Calc {
    const val ACEITAR = 0
    const val AVALIAR = 1
    const val RECUSAR = 2

    data class Result(
        val price: Double, val km: Double, val min: Double,
        val rKm: Double, val rH: Double,
        val custo: Double, val lucro: Double, val lucroPct: Double,
        val nota: Double, val verdict: Int,
        val okKm: Boolean, val okH: Boolean
    )

    fun run(price: Double, km: Double, min: Double, c: Config): Result {
        val rKm = price / km
        val rH = price / (min / 60.0)
        val consumo = if (c.consumo > 0) c.consumo else 1.0
        val custo = km * (c.preco / consumo + c.outros)
        val lucro = price - custo
        val pct = (lucro / price * 100.0).coerceAtLeast(0.0)

        fun cl(x: Double) = if (x.isNaN()) 0.0 else x.coerceIn(0.0, 1.0)
        val nota = 5.0 * (0.40 * cl(rKm / (c.kmMin * 1.4)) +
                0.35 * cl(rH / (c.hMin * 1.4)) +
                0.25 * cl(pct / 85.0))

        val okKm = rKm >= c.kmMin
        val okH = rH >= c.hMin
        val v = when {
            okKm && okH -> ACEITAR
            okKm || okH -> AVALIAR
            else -> RECUSAR
        }
        return Result(price, km, min, rKm, rH, custo, lucro, pct, nota, v, okKm, okH)
    }

    private val br = Locale("pt", "BR")
    fun f2(d: Double): String = String.format(br, "%.2f", d)
    fun f1(d: Double): String = String.format(br, "%.1f", d).removeSuffix(",0")
    fun f0(d: Double): String = String.format(br, "%.0f", d)
}
