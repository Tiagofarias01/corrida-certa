package com.corridacerta

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Lê a tela de oferta da Uber / 99 / inDrive e mostra um aviso por cima.
 * Só LÊ e MOSTRA: não toca em nada, não aceita e não recusa corridas.
 */
class OfferService : AccessibilityService() {

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var overlay: View? = null
    private var lastSig = ""
    private var lastFail = ""
    private var dismissedSig = ""
    private var lastRun = 0L
    private val hideRunnable = Runnable { removeOverlay() }

    companion object {
        @Volatile var instance: OfferService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        instance = this
    }

    /** Mostra um aviso de exemplo (botão "Testar aviso" no app). */
    fun showTest() {
        main.post { show("com.ubercab.driver", OfferParser.Offer(18.50, 9.5, 20.0)) }
    }

    private fun isTarget(pkg: String?): Boolean {
        if (pkg == null || pkg == packageName) return false
        val p = pkg.lowercase()
        return p.startsWith("com.ubercab") || p.contains("app99") || p.contains("99app") ||
                p.contains("taxis99") || p.contains("indriver")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val evPkg = event.packageName?.toString()
        if (evPkg != null && !isTarget(evPkg)) return

        val now = SystemClock.uptimeMillis()
        if (now - lastRun < 350) return
        lastRun = now

        val sb = StringBuilder()
        var pkgFound: String? = null
        try {
            for (w in windows) {
                val root = w.root ?: continue
                val rp = root.packageName?.toString()
                if (!isTarget(rp)) continue
                pkgFound = rp
                collect(root, sb, 0)
            }
        } catch (_: Exception) { }
        if (sb.isEmpty()) {
            val root = rootInActiveWindow
            val rp = root?.packageName?.toString()
            if (root != null && isTarget(rp)) {
                pkgFound = rp
                collect(root, sb, 0)
            }
        }
        val text = sb.toString()
        val pkg = pkgFound ?: return
        if (!text.contains("R$")) return

        val offer = OfferParser.parse(text)
        if (offer == null) {
            // só guarda telas que parecem oferta (têm "km"), para não encher com a tela inicial
            if (text != lastFail && text.contains("km", ignoreCase = true)) {
                lastFail = text
                Prefs.saveCapture(this, pkg, text, false)
            }
            return
        }
        val sig = "${offer.price}|${offer.km}|${offer.min}"
        if (sig == dismissedSig) return
        if (sig == lastSig && overlay != null) {
            restartTimer()
            return
        }
        lastSig = sig
        Prefs.saveCapture(this, pkg, text, true)
        main.post { show(pkg, offer) }
    }

    private fun collect(n: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (n == null || depth > 60) return
        val t = n.text?.toString()
        val d = n.contentDescription?.toString()
        when {
            !t.isNullOrBlank() -> sb.append(t).append(" | ")
            !d.isNullOrBlank() -> sb.append(d).append(" | ")
        }
        for (i in 0 until n.childCount) {
            collect(n.getChild(i), sb, depth + 1)
        }
    }

    // ---------- Aviso na tela ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun appName(pkg: String): String {
        val p = pkg.lowercase()
        return when {
            p.contains("uber") -> "Uber"
            p.contains("indriver") -> "inDrive"
            else -> "99"
        }
    }

    private fun show(pkg: String, o: OfferParser.Offer) {
        val r = Calc.run(o.price, o.km, o.min, Prefs.config(this))
        removeOverlay()

        val green = Color.parseColor("#1FAE5B")
        val yellow = Color.parseColor("#E0A21B")
        val red = Color.parseColor("#E04646")
        val color = when (r.verdict) {
            Calc.ACEITAR -> green
            Calc.AVALIAR -> yellow
            else -> red
        }
        val label = when (r.verdict) {
            Calc.ACEITAR -> "✓ ACEITAR"
            Calc.AVALIAR -> "ⓘ AVALIAR"
            else -> "✕ RECUSAR"
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(18).toFloat()
                setStroke(dp(4), color)
            }
            elevation = dp(10).toFloat()
        }

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(4), dp(12), dp(4))
            background = GradientDrawable().apply {
                setColor(color); cornerRadius = dp(10).toFloat()
            }
        })
        head.addView(TextView(this).apply {
            text = "  ${appName(pkg)} · ${Calc.f0(r.min)} min · ${Calc.f1(r.km)} km · R$ ${Calc.f2(r.price)}"
            setTextColor(Color.parseColor("#14201B"))
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
        })
        card.addView(head)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }
        fun cell(title: String, value: String, ok: Boolean?) {
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            c.addView(TextView(this).apply {
                text = title; textSize = 11f
                setTextColor(Color.parseColor("#4B5A53"))
                typeface = Typeface.DEFAULT_BOLD
            })
            c.addView(TextView(this).apply {
                text = value; textSize = 22f
                setTextColor(Color.parseColor("#14201B"))
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(6), 0, 0, 0)
                val bar = when (ok) { true -> green; false -> red; null -> yellow }
                // barra lateral colorida
                val b = GradientDrawable().apply {
                    setColor(bar); setSize(dp(4), dp(26)); cornerRadius = dp(2).toFloat()
                }
                b.setBounds(0, 0, dp(4), dp(26))
                setCompoundDrawablesRelative(b, null, null, null)
                compoundDrawablePadding = dp(6)
            })
            row.addView(c, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        cell("R$/km", Calc.f2(r.rKm), r.okKm)
        cell("R$/Hora", Calc.f0(r.rH), r.okH)
        cell("Lucro (%)", Calc.f0(r.lucroPct), if (r.lucroPct >= 60) true else if (r.lucroPct >= 40) null else false)
        cell("Nota", Calc.f2(r.nota), if (r.nota >= 3.5) true else if (r.nota >= 2.5) null else false)
        card.addView(row)

        card.addView(TextView(this).apply {
            text = "Custo R$ ${Calc.f2(r.custo)}  ·  Lucro R$ ${Calc.f2(r.lucro)}   (toque para fechar)"
            textSize = 12f
            setTextColor(Color.parseColor("#4B5A53"))
            setPadding(0, dp(8), 0, 0)
        })

        val wrap = FrameLayout(this).apply {
            setPadding(dp(10), 0, dp(10), 0)
            addView(card)
            setOnClickListener { dismissedSig = lastSig; removeOverlay() }
        }
        card.setOnClickListener { dismissedSig = lastSig; removeOverlay() }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP
            y = dp(60)
        }

        try {
            wm?.addView(wrap, lp)
            overlay = wrap
            restartTimer()
        } catch (_: Exception) {
            overlay = null
        }
    }

    private fun restartTimer() {
        main.removeCallbacks(hideRunnable)
        main.postDelayed(hideRunnable, 15_000)
    }

    private fun removeOverlay() {
        main.removeCallbacks(hideRunnable)
        overlay?.let { v -> try { wm?.removeView(v) } catch (_: Exception) { } }
        overlay = null
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        removeOverlay()
        super.onDestroy()
    }
}
