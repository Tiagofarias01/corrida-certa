package com.corridacerta

import android.content.Context

data class Config(
    val preco: Double,   // R$ por litro
    val consumo: Double, // km por litro
    val outros: Double,  // R$ por km (manutenção, pneu, seguro...)
    val kmMin: Double,   // meta mínima R$/km
    val hMin: Double     // meta mínima R$/hora
)

object Prefs {
    private const val NAME = "corrida_certa"
    private const val SEP = "\u0001"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun config(ctx: Context): Config {
        val p = sp(ctx)
        return Config(
            p.getFloat("preco", 6.19f).toDouble(),
            p.getFloat("consumo", 11f).toDouble(),
            p.getFloat("outros", 0.25f).toDouble(),
            p.getFloat("kmMin", 1.5f).toDouble(),
            p.getFloat("hMin", 40f).toDouble()
        )
    }

    fun save(ctx: Context, c: Config) {
        sp(ctx).edit()
            .putFloat("preco", c.preco.toFloat())
            .putFloat("consumo", c.consumo.toFloat())
            .putFloat("outros", c.outros.toFloat())
            .putFloat("kmMin", c.kmMin.toFloat())
            .putFloat("hMin", c.hMin.toFloat())
            .apply()
    }

    /** Guarda os últimos textos lidos das telas de oferta (para ajuste fino). */
    fun saveCapture(ctx: Context, pkg: String, text: String, ok: Boolean) {
        val p = sp(ctx)
        val entry = "[$pkg] " + (if (ok) "LIDA OK" else "NÃO CONSEGUI LER") + "\n" + text.take(1500)
        val old = (p.getString("log", "") ?: "").split(SEP).filter { it.isNotBlank() }
        val list = (listOf(entry) + old).take(5)
        p.edit().putString("log", list.joinToString(SEP)).apply()
    }

    fun log(ctx: Context): String =
        (sp(ctx).getString("log", "") ?: "").split(SEP).filter { it.isNotBlank() }
            .joinToString("\n\n----------\n\n")

    fun clearLog(ctx: Context) = sp(ctx).edit().remove("log").apply()
}
