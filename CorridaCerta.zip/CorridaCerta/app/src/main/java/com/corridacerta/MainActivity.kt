package com.corridacerta

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private val fields = linkedMapOf<String, EditText>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(28))
            setBackgroundColor(Color.parseColor("#0B1310"))
        }

        root.addView(text("Corrida Certa", 26f, "#FFFFFF", true))
        root.addView(text("Aviso automático em cima da oferta da Uber, 99 e inDrive.", 14f, "#8FA59A", false))

        // ---- Passo 1: ativar ----
        root.addView(section("1. Ativar o aviso"))
        status = text("", 15f, "#FFFFFF", true)
        root.addView(status)
        root.addView(button("Abrir Acessibilidade e ativar \"Corrida Certa\"") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(text(
            "Se a opção aparecer apagada (Android 13 ou mais novo): vá em Configurações > Apps > " +
            "Corrida Certa > ⋮ (canto de cima) > \"Permitir configurações restritas\" e tente de novo.",
            13f, "#8FA59A", false))

        // ---- Passo 2: carro ----
        val c = Prefs.config(this)
        root.addView(section("2. Seu carro"))
        root.addView(field("preco", "Combustível (R$ por litro)", c.preco))
        root.addView(field("consumo", "Consumo (km por litro)", c.consumo))
        root.addView(field("outros", "Outros custos por km (manutenção, pneu, seguro) R$/km", c.outros))

        root.addView(section("3. Suas metas mínimas"))
        root.addView(field("kmMin", "Mínimo R$ por km", c.kmMin))
        root.addView(field("hMin", "Mínimo R$ por hora", c.hMin))
        root.addView(text(
            "Bateu as duas = ACEITAR (verde). Só uma = AVALIAR (amarelo). Nenhuma = RECUSAR (vermelho).",
            13f, "#8FA59A", false))

        root.addView(button("Salvar") { save() })

        // ---- Diagnóstico ----
        root.addView(section("Últimas ofertas lidas"))
        root.addView(text(
            "Se o aviso não aparecer, abra a oferta na Uber/99, volte aqui, toque em Copiar e mande o texto " +
            "para quem fez o app ajustar a leitura.", 13f, "#8FA59A", false))
        logView = text("", 12f, "#C9D6CF", false).apply { setTextIsSelectable(true) }
        root.addView(logView)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("Copiar") { copyLog() }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button("Limpar") { Prefs.clearLog(this); refresh() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B1310"))
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val on = isServiceOn()
        status.text = if (on) "● Ativado — o aviso vai aparecer quando tocar uma corrida"
                      else "● Desativado — toque no botão abaixo"
        status.setTextColor(Color.parseColor(if (on) "#1FAE5B" else "#E04646"))
        val log = Prefs.log(this)
        logView.text = if (log.isBlank()) "(nada lido ainda)" else log
    }

    private fun isServiceOn(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any {
            it.startsWith("$packageName/") && it.endsWith("OfferService")
        }
    }

    private fun num(key: String): Double =
        fields[key]?.text?.toString()?.trim()?.replace(',', '.')?.toDoubleOrNull() ?: 0.0

    private fun save() {
        Prefs.save(this, Config(num("preco"), num("consumo"), num("outros"), num("kmMin"), num("hMin")))
        Toast.makeText(this, "Salvo ✓", Toast.LENGTH_SHORT).show()
    }

    private fun copyLog() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Corrida Certa", Prefs.log(this)))
        Toast.makeText(this, "Copiado ✓", Toast.LENGTH_SHORT).show()
    }

    // ---------- helpers de layout ----------

    private fun text(s: String, size: Float, color: String, bold: Boolean) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(Color.parseColor(color))
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun section(s: String) = text(s, 16f, "#1FAE5B", true).apply {
        setPadding(0, dp(22), 0, dp(6))
    }

    private fun button(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s
        isAllCaps = false
        textSize = 15f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#1FAE5B")); cornerRadius = dp(14).toFloat()
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(2), dp(8), dp(2), dp(4)) }
    }

    private fun field(key: String, label: String, value: Double): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(text(label, 13f, "#8FA59A", true))
        val et = EditText(this).apply {
            setText(Calc.f2(value))
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            keyListener = android.text.method.DigitsKeyListener.getInstance("0123456789.,")
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#14201B"))
                setStroke(dp(1), Color.parseColor("#26362F"))
                cornerRadius = dp(12).toFloat()
            }
        }
        fields[key] = et
        box.addView(et)
        return box
    }
}
