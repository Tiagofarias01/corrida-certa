# Corrida Certa: aviso automático na oferta da Uber, 99 e inDrive

Quando uma corrida toca, aparece um cartão no topo da tela com ACEITAR / AVALIAR / RECUSAR,
R$/km, R$/hora, lucro (%) e nota. O app só LÊ a tela e mostra o aviso: não aceita nem recusa nada sozinho.

## Gerar o instalador (APK)

### Opção A: computador (Android Studio, grátis)
1. Instale o Android Studio: https://developer.android.com/studio
2. Descompacte este .zip e, no Android Studio, vá em File > Open e escolha a pasta CorridaCerta.
3. Espere terminar o "Gradle sync" (a primeira vez demora, porque baixa coisas).
4. Menu Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. O arquivo fica em: app/build/outputs/apk/debug/app-debug.apk
6. Passe o arquivo para o celular (WhatsApp, Drive, cabo) e toque nele para instalar.
   Se o celular pedir, permita "instalar apps desconhecidos".

### Opção B: só pelo celular (GitHub, grátis)
1. Crie uma conta em github.com e um repositório novo.
2. Envie todos os arquivos desta pasta para o repositório (Add file > Upload files).
   A pasta .github precisa ir junto.
3. Abra a aba "Actions". O "Gerar APK" roda sozinho (uns 5 minutos).
4. Quando ficar verde, abra a execução e baixe "CorridaCerta-apk" (é um .zip com o APK dentro).

## Configurar no celular
1. Abra o Corrida Certa e preencha: preço do combustível, consumo, outros custos por km e as suas metas. Toque em Salvar.
2. Toque em "Abrir Acessibilidade", entre em Corrida Certa (pode estar em "Apps instalados" ou "Serviços baixados") e ative.
3. Android 13 ou mais novo: se a opção estiver apagada, vá em Configurações > Apps > Corrida Certa >
   ⋮ (canto de cima) > "Permitir configurações restritas" e ative de novo.
4. Na Xiaomi/Redmi/Poco: deixe "Sem restrições" em Economia de bateria para o app, senão o sistema desliga ele.

## Se o aviso não aparecer
A Uber e a 99 mudam o visual de vez em quando. Abra o Corrida Certa, veja "Últimas ofertas lidas",
toque em Copiar e mande o texto para ajustar a leitura (arquivo OfferParser.kt).

## Avisos
- A Uber diz que ferramentas de automação violam os termos dela. Este app não automatiza nada, só mostra informação, mas use por sua conta.
- Recusar muitas corridas pode reduzir chamadas ou gerar suspensão nas plataformas.
